"use client";

import { motion } from "framer-motion";
import {
  Car,
  Wrench,
  Sun,
  Battery,
  ShieldCheck,
  ShoppingBag,
  ArrowRight,
} from "lucide-react";
import ScrollReveal from "./ScrollReveal";
import Link from "next/link";

const services = [
  {
    icon: Car,
    title: "Automobile Sales",
    description:
      "Brand new, foreign used, and Nigerian used vehicles. Expert sourcing and thorough inspection for your peace of mind.",
    color: "from-[#0B1F3A] to-[#132d52]",
    glowColor: "group-hover:shadow-[#0B1F3A]/10",
  },
  {
    icon: Wrench,
    title: "Auto Parts",
    description:
      "Original spare parts, vehicle accessories, engine components, and quality maintenance supplies for all vehicle makes.",
    color: "from-[#2563EB] to-[#1d4ed8]",
    glowColor: "group-hover:shadow-[#2563EB]/10",
  },
  {
    icon: Sun,
    title: "Solar Energy",
    description:
      "Complete solar systems — panels, batteries, inverters — with professional installation and ongoing maintenance.",
    color: "from-[#10B981] to-[#059669]",
    glowColor: "group-hover:shadow-[#10B981]/10",
  },
  {
    icon: Battery,
    title: "Inverter Solutions",
    description:
      "Home and office backup power systems with expert installation, seamless integration, and reliable maintenance.",
    color: "from-[#F59E0B] to-[#D97706]",
    glowColor: "group-hover:shadow-[#F59E0B]/10",
  },
  {
    icon: ShieldCheck,
    title: "CCTV & Security",
    description:
      "IP cameras, DVR/NVR, video doorbells, motion sensors, alarms, and electric fences — all professionally installed.",
    color: "from-[#EF4444] to-[#DC2626]",
    glowColor: "group-hover:shadow-[#EF4444]/10",
  },
  {
    icon: ShoppingBag,
    title: "General Merchandise",
    description:
      "Premium electronics, home appliances, household products, and commercial equipment — sourced for quality.",
    color: "from-[#8B5CF6] to-[#7C3AED]",
    glowColor: "group-hover:shadow-[#8B5CF6]/10",
  },
];

export default function Services() {
  return (
    <section id="services" className="relative py-24 lg:py-32 mesh-gradient-light overflow-hidden">
      {/* Decorative blobs */}
      <div className="absolute top-40 -left-40 w-80 h-80 bg-[#2563EB]/5 rounded-full blur-[100px]" />
      <div className="absolute bottom-40 -right-40 w-80 h-80 bg-[#10B981]/5 rounded-full blur-[100px]" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16 lg:mb-20">
          <ScrollReveal>
            <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#2563EB]/10 text-[#2563EB] text-sm font-semibold mb-4">
              Our Services
            </span>
          </ScrollReveal>
          <ScrollReveal delay={0.1}>
            <h2 className="font-[family-name:var(--font-space-grotesk)] text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1F3A] tracking-tight">
              Everything You Need,{" "}
              <span className="gradient-text">One Trusted Partner</span>
            </h2>
          </ScrollReveal>
          <ScrollReveal delay={0.2}>
            <p className="mt-5 text-lg text-[#6B7280] leading-relaxed">
              From premium automobiles to reliable solar energy and comprehensive
              security systems — we deliver excellence across every service line.
            </p>
          </ScrollReveal>
        </div>

        {/* Services Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {services.map((service, i) => (
            <ScrollReveal key={i} delay={i * 0.08}>
              <motion.div
                whileHover={{ y: -8 }}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
                className={`group relative bg-white rounded-2xl p-8 shadow-premium hover:shadow-premium-hover border border-white/80 transition-all duration-500 h-full ${service.glowColor}`}
              >
                {/* Icon */}
                <div className="relative mb-6">
                  <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${service.color} flex items-center justify-center shadow-lg group-hover:scale-110 group-hover:rotate-3 transition-all duration-300`}>
                    <service.icon className="w-7 h-7 text-white" />
                  </div>
                  <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${service.color} opacity-0 group-hover:opacity-20 blur-xl transition-opacity duration-300`} />
                </div>

                {/* Content */}
                <h3 className="font-[family-name:var(--font-space-grotesk)] text-xl font-bold text-[#0B1F3A] mb-3">
                  {service.title}
                </h3>
                <p className="text-[#6B7280] leading-relaxed mb-6 text-sm">
                  {service.description}
                </p>

                {/* Link */}
                <Link
                  href="#contact"
                  className="inline-flex items-center gap-2 text-sm font-semibold text-[#2563EB] hover:text-[#0B1F3A] group/link transition-colors"
                >
                  Learn More
                  <ArrowRight className="w-4 h-4 group-hover/link:translate-x-1 transition-transform" />
                </Link>

                {/* Corner accent */}
                <div className="absolute top-0 right-0 w-20 h-20 overflow-hidden rounded-tr-2xl">
                  <div className={`absolute -top-10 -right-10 w-20 h-20 bg-gradient-to-br ${service.color} opacity-5 group-hover:opacity-10 transition-opacity rounded-full`} />
                </div>
              </motion.div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
}
