"use client";

import {
  Award,
  BadgeCheck,
  BadgeDollarSign,
  Truck,
  ShieldCheck,
  Headphones,
  FileCheck,
  CalendarCheck,
} from "lucide-react";
import ScrollReveal from "./ScrollReveal";

const reasons = [
  { icon: CalendarCheck, text: "Experienced Professionals" },
  { icon: BadgeCheck, text: "Original Products Only" },
  { icon: BadgeDollarSign, text: "Affordable Pricing" },
  { icon: Truck, text: "Nationwide Delivery" },
  { icon: ShieldCheck, text: "Professional Installation" },
  { icon: Headphones, text: "Excellent Support" },
  { icon: FileCheck, text: "Comprehensive Warranty" },
  { icon: Award, text: "Trusted Since 2008" },
];

export default function WhyChoose() {
  return (
    <section id="about" className="relative py-24 lg:py-32 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left */}
          <div>
            <ScrollReveal direction="left">
              <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#10B981]/10 text-[#10B981] text-sm font-semibold mb-4">
                Why Choose Us
              </span>
            </ScrollReveal>
            <ScrollReveal direction="left" delay={0.1}>
              <h2 className="font-[family-name:var(--font-space-grotesk)] text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1F3A] tracking-tight leading-tight">
                Built on Trust,{" "}
                <span className="gradient-text">Delivered with Excellence</span>
              </h2>
            </ScrollReveal>
            <ScrollReveal direction="left" delay={0.2}>
              <p className="mt-6 text-lg text-[#6B7280] leading-relaxed">
                Founded in 2008 by <strong className="text-[#0B1F3A]">John Funmilola Akinwunmi</strong>,
                Jest Smart Services Ltd has grown into one of Nigeria&apos;s most trusted
                providers of smart home and business solutions. We combine premium
                products with expert installation and genuine after-sales care.
              </p>
            </ScrollReveal>
            <ScrollReveal direction="left" delay={0.3}>
              <p className="mt-4 text-lg text-[#6B7280] leading-relaxed">
                Our commitment is simple: deliver reliable, innovative solutions
                that make your life smarter, safer, and more convenient — every
                single time.
              </p>
            </ScrollReveal>
          </div>

          {/* Right - Reasons Grid */}
          <div className="grid grid-cols-2 gap-4">
            {reasons.map((reason, i) => (
              <ScrollReveal key={i} direction="right" delay={i * 0.05}>
                <div className="group flex items-center gap-3 p-4 rounded-2xl bg-white border border-[#E5E7EB]/60 shadow-sm hover:shadow-premium hover:border-[#2563EB]/20 hover:-translate-y-1 transition-all duration-300">
                  <div className="flex-shrink-0 w-10 h-10 rounded-xl bg-gradient-to-br from-[#2563EB]/10 to-[#10B981]/10 flex items-center justify-center group-hover:from-[#2563EB] group-hover:to-[#10B981] transition-all duration-300">
                    <reason.icon className="w-5 h-5 text-[#2563EB] group-hover:text-white transition-colors duration-300" />
                  </div>
                  <span className="text-sm font-semibold text-[#0B1F3A]">
                    {reason.text}
                  </span>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
