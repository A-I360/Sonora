"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Check, ArrowRight, Sparkles, Building2, Home, Crown } from "lucide-react";
import ScrollReveal from "./ScrollReveal";

const categories = [
  {
    title: "Solar Packages",
    description: "Complete solar energy solutions for every need",
    icon: Sparkles,
    color: "from-[#10B981] to-[#059669]",
    plans: [
      {
        name: "Basic",
        desc: "Perfect for small homes",
        features: ["1-3kW System", "Basic Inverter", "Standard Panels", "1-Year Warranty", "Professional Installation"],
      },
      {
        name: "Standard",
        desc: "Ideal for family homes",
        features: ["3-5kW System", "Hybrid Inverter", "Premium Panels", "Battery Backup", "2-Year Warranty", "Free Maintenance (6mo)"],
        featured: true,
      },
      {
        name: "Premium",
        desc: "Complete energy independence",
        features: ["5-10kW+ System", "Smart Inverter", "Tier-1 Panels", "Full Battery Bank", "5-Year Warranty", "24/7 Monitoring"],
      },
    ],
  },
  {
    title: "Security Packages",
    description: "Comprehensive surveillance and protection",
    icon: Building2,
    color: "from-[#2563EB] to-[#1d4ed8]",
    plans: [
      {
        name: "Home",
        desc: "Essential home security",
        features: ["4-8 Cameras", "DVR System", "Mobile Access", "Night Vision", "1-Year Warranty"],
      },
      {
        name: "Business",
        desc: "Commercial-grade protection",
        features: ["8-16 IP Cameras", "NVR System", "Remote Monitoring", "Motion Alerts", "Electric Fence", "2-Year Warranty"],
        featured: true,
      },
      {
        name: "Enterprise",
        desc: "Maximum security infrastructure",
        features: ["16+ Cameras", "AI Analytics", "Access Control", "Alarm Integration", "Dedicated Support", "3-Year Warranty"],
      },
    ],
  },
  {
    title: "Installation Services",
    description: "Custom solutions tailored to you",
    icon: Crown,
    color: "from-[#0B1F3A] to-[#132d52]",
    plans: [
      {
        name: "Consultation",
        desc: "Expert assessment",
        features: ["Site Survey", "Needs Analysis", "Custom Proposal", "Budget Planning", "Timeline Estimate"],
      },
      {
        name: "Full Service",
        desc: "End-to-end delivery",
        features: ["Everything in Consultation", "Product Sourcing", "Professional Installation", "Testing & Commissioning", "Training & Handover"],
        featured: true,
      },
      {
        name: "Maintenance",
        desc: "Ongoing care plan",
        features: ["Regular Inspections", "Preventive Maintenance", "Priority Support", "Emergency Response", "System Upgrades"],
      },
    ],
  },
];

export default function Pricing() {
  return (
    <section className="relative py-24 lg:py-32 overflow-hidden mesh-gradient-light">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-16 lg:mb-20">
          <ScrollReveal>
            <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#2563EB]/10 text-[#2563EB] text-sm font-semibold mb-4">
              Pricing
            </span>
          </ScrollReveal>
          <ScrollReveal delay={0.1}>
            <h2 className="font-[family-name:var(--font-space-grotesk)] text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1F3A] tracking-tight">
              Flexible Packages,{" "}
              <span className="gradient-text">Transparent Pricing</span>
            </h2>
          </ScrollReveal>
          <ScrollReveal delay={0.2}>
            <p className="mt-5 text-lg text-[#6B7280] leading-relaxed">
              Every project is unique. Get a personalized quote tailored to your
              specific needs and budget.
            </p>
          </ScrollReveal>
        </div>

        {/* Pricing Categories */}
        <div className="space-y-16">
          {categories.map((category, ci) => (
            <ScrollReveal key={ci}>
              <div>
                <div className="flex items-center gap-3 mb-8">
                  <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${category.color} flex items-center justify-center shadow-lg`}>
                    <category.icon className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-[family-name:var(--font-space-grotesk)] text-xl font-bold text-[#0B1F3A]">
                      {category.title}
                    </h3>
                    <p className="text-sm text-[#6B7280]">{category.description}</p>
                  </div>
                </div>

                <div className="grid md:grid-cols-3 gap-6">
                  {category.plans.map((plan, pi) => (
                    <motion.div
                      key={pi}
                      whileHover={{ y: -4 }}
                      transition={{ type: "spring", stiffness: 300, damping: 20 }}
                      className={`relative rounded-2xl p-8 transition-all duration-500 h-full flex flex-col ${
                        plan.featured
                          ? "bg-[#0B1F3A] text-white shadow-xl shadow-[#0B1F3A]/20 scale-[1.02]"
                          : "bg-white shadow-premium border border-white/80 hover:shadow-premium-hover"
                      }`}
                    >
                      {plan.featured && (
                        <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-[#2563EB] to-[#10B981] text-white text-xs font-semibold shadow-lg">
                          Most Popular
                        </span>
                      )}

                      <div className="mb-6">
                        <h4 className={`font-[family-name:var(--font-space-grotesk)] text-lg font-bold ${plan.featured ? "text-white" : "text-[#0B1F3A]"}`}>
                          {plan.name}
                        </h4>
                        <p className={`text-sm mt-1 ${plan.featured ? "text-white/60" : "text-[#6B7280]"}`}>
                          {plan.desc}
                        </p>
                      </div>

                      <div className={`text-2xl font-bold mb-6 ${plan.featured ? "text-white" : "text-[#0B1F3A]"}`}>
                        Custom Quote
                      </div>

                      <ul className="space-y-3 mb-8 flex-1">
                        {plan.features.map((feature, fi) => (
                          <li key={fi} className="flex items-start gap-2 text-sm">
                            <Check className={`w-4 h-4 mt-0.5 flex-shrink-0 ${plan.featured ? "text-[#10B981]" : "text-[#10B981]"}`} />
                            <span className={plan.featured ? "text-white/80" : "text-[#374151]"}>
                              {feature}
                            </span>
                          </li>
                        ))}
                      </ul>

                      <Link
                        href="#contact"
                        className={`w-full inline-flex items-center justify-center gap-2 px-6 py-3 rounded-full font-semibold text-sm transition-all duration-300 ${
                          plan.featured
                            ? "bg-white text-[#0B1F3A] hover:bg-white/90 hover:scale-105"
                            : "bg-[#0B1F3A] text-white hover:bg-[#132d52] hover:scale-105"
                        }`}
                      >
                        Request Quote
                        <ArrowRight className="w-4 h-4" />
                      </Link>
                    </motion.div>
                  ))}
                </div>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
}
