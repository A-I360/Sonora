# Jest Smart Services Ltd - Premium Landing Page

A world-class, conversion-focused landing page built with Next.js 15, TypeScript, Tailwind CSS, and Framer Motion. Inspired by Apple, Stripe, Linear, and Tesla design aesthetics.

![Jest Smart Services](public/hero-image.jpg)

## 🌟 Features

### Design & UX
- **Premium Aesthetic**: Apple/Stripe-inspired design with elegant gradients, glassmorphism, and modern spacing
- **Fully Responsive**: Mobile-first design optimized for all devices (mobile, tablet, desktop, ultra-wide)
- **Smooth Animations**: Scroll-triggered reveals, parallax effects, floating cards, and micro-interactions
- **Accessibility**: WCAG compliant with keyboard navigation, proper focus states, and semantic HTML
- **Performance**: Optimized for 95+ Lighthouse scores with lazy loading and code splitting

### Sections
1. **Sticky Navbar** - Glass effect, responsive menu, smooth scroll navigation
2. **Hero Section** - Large headline, animated background, floating feature cards, dual CTAs
3. **Stats Counter** - Animated counters showing experience, customers, projects, satisfaction
4. **Services Grid** - 6 service cards with hover effects and premium icons
5. **Why Choose Us** - Split layout with 8 key differentiators
6. **Product Showcase** - 4 product categories with images, features, and CTAs
7. **Process Timeline** - 4-step animated timeline showing how it works
8. **Benefits Grid** - 7 key benefits with elegant icons
9. **Testimonials Carousel** - Embla carousel with customer reviews and ratings
10. **Pricing Packages** - 3 pricing categories (Solar, Security, Installation) with custom quotes
11. **FAQ Accordion** - 6 common questions with smooth expand/collapse
12. **Final CTA** - Large conversion section with email and contact buttons
13. **Footer** - Company info, quick links, services, legal, social media

### Technical Features
- **SEO Optimized**: Meta tags, Open Graph, Twitter Cards, JSON-LD schema
- **Type Safety**: Full TypeScript implementation
- **Component Architecture**: Reusable, modular components
- **Custom Fonts**: Space Grotesk (headings) + Inter (body)
- **Custom Animations**: Framer Motion for smooth, performant animations
- **Mouse Tracking Glow**: Subtle ambient glow following cursor
- **Animated Counters**: Intersection Observer-based number animations
- **Carousel**: Embla Carousel for testimonials
- **Form Ready**: React Hook Form integrated (ready for contact form)

## 🎨 Design System

### Color Palette
- **Primary**: Deep Navy `#0B1F3A`
- **Secondary**: Royal Blue `#2563EB`
- **Accent**: Emerald `#10B981`
- **Background**: `#F8FAFC`
- **Dark Sections**: `#081018`
- **Text**: `#111827`
- **Muted**: `#6B7280`

### Typography
- **Headings**: Space Grotesk (bold, tracking-tight)
- **Body**: Inter (regular, optimized readability)

### Effects
- Glass morphism with backdrop blur
- Mesh gradients and animated blobs
- Premium shadows with multiple layers
- Gradient text effects
- Hover lift animations
- Glow effects on interactive elements

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ 
- npm or yarn

### Installation

```bash
# Navigate to project directory
cd jest-smart

# Install dependencies (already done)
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Start production server
npm start
```

### Development
Open [http://localhost:3000](http://localhost:3000) in your browser.

The page auto-reloads on edits. Check the console for any errors.

## 📁 Project Structure

```
jest-smart/
├── public/                 # Static assets
│   ├── hero-image.jpg     # AI-generated hero image
│   ├── solar.jpg          # Solar panels product image
│   ├── cctv.jpg           # Security camera product image
│   ├── vehicle.jpg        # Vehicle product image
│   └── inverter.jpg       # Inverter product image
├── src/
│   ├── app/
│   │   ├── layout.tsx     # Root layout with fonts, metadata, JSON-LD
│   │   ├── page.tsx       # Main page assembling all sections
│   │   └── globals.css    # Global styles, animations, custom CSS
│   └── components/
│       ├── Navbar.tsx     # Sticky navigation with mobile menu
│       ├── Hero.tsx       # Hero section with animations
│       ├── Stats.tsx      # Animated counters
│       ├── Services.tsx   # Services grid
│       ├── WhyChoose.tsx  # Why choose us section
│       ├── Products.tsx   # Product showcase
│       ├── Process.tsx    # How it works timeline
│       ├── Benefits.tsx   # Benefits grid
│       ├── Testimonials.tsx # Customer reviews carousel
│       ├── Pricing.tsx    # Pricing packages
│       ├── FAQ.tsx        # FAQ accordion
│       ├── CTA.tsx        # Call-to-action section
│       ├── Footer.tsx     # Footer with links
│       ├── ScrollReveal.tsx # Scroll animation wrapper
│       └── MouseGlow.tsx  # Mouse tracking glow effect
└── package.json

```

## 🔧 Technologies Used

- **Framework**: Next.js 16.2.11 (App Router)
- **Language**: TypeScript 5
- **Styling**: Tailwind CSS 4
- **Animations**: Framer Motion 12
- **Icons**: Lucide React + Custom SVGs
- **Carousel**: Embla Carousel React 8
- **Forms**: React Hook Form 7
- **Fonts**: Google Fonts (Inter, Space Grotesk)

## 📱 Responsive Breakpoints

- **Mobile**: < 640px
- **Tablet**: 640px - 1024px
- **Desktop**: 1024px - 1280px
- **Ultra-wide**: > 1280px

## 🎯 Conversion Features

- **Strategic CTAs**: Multiple "Get a Quote" and "Request Quote" buttons throughout
- **Trust Indicators**: Stats, testimonials, ratings, years in business
- **Social Proof**: Customer reviews with photos and ratings
- **Clear Value Props**: Benefits section highlighting key advantages
- **Easy Contact**: Email links, quick response promises
- **Professional Design**: Builds credibility and trust

## 🔍 SEO Features

- Semantic HTML5 structure
- Meta title and description
- Open Graph tags for social sharing
- Twitter Card meta tags
- JSON-LD LocalBusiness schema
- Proper heading hierarchy (h1 → h2 → h3)
- Alt text on all images
- Optimized image loading

## ♿ Accessibility

- WCAG 2.1 AA compliant
- Keyboard navigation support
- Focus visible states
- ARIA labels and roles
- Semantic landmarks
- Color contrast ratios > 4.5:1
- Screen reader friendly

## 🎨 Customization

### Colors
Edit `src/app/globals.css` and modify the `@theme inline` section:

```css
@theme inline {
  --color-navy: #0B1F3A;
  --color-royal: #2563EB;
  --color-emerald: #10B981;
  /* ... */
}
```

### Content
Each section component contains its own data arrays for easy content updates:
- `Services.tsx` - services array
- `Products.tsx` - products array
- `Testimonials.tsx` - testimonials array
- `Pricing.tsx` - categories and plans arrays
- `FAQ.tsx` - faqs array

### Images
Replace images in `/public/` directory:
- `hero-image.jpg` - Hero section background
- `solar.jpg`, `cctv.jpg`, `vehicle.jpg`, `inverter.jpg` - Product images

## 📊 Performance

- **Build Size**: ~9.3MB (production build)
- **Page Load**: Optimized with Next.js static generation
- **Images**: Next.js Image component with automatic optimization
- **Code Splitting**: Automatic per-component
- **Animations**: GPU-accelerated with Framer Motion

## 🌐 Deployment

### Vercel (Recommended)
```bash
npm install -g vercel
vercel
```

### Other Platforms
- **Netlify**: Connect GitHub repo, build command: `npm run build`, publish: `.next`
- **AWS Amplify**: Connect repo, use Next.js preset
- **Docker**: Create Dockerfile with `npm run build` and `npm start`

## 📝 License

This project is created for Jest Smart Services Ltd.

## 👤 Company Information

- **Business**: Jest Smart Services Ltd
- **Founder**: John Funmilola Akinwunmi
- **Founded**: 2008
- **Email**: jestsmartservicesltd001@gmail.com
- **Location**: Abuja, FCT, Nigeria

## 🛠️ Development Notes

- All components use `"use client"` directive for client-side interactivity
- ScrollReveal wrapper uses Intersection Observer for performance
- Mouse tracking glow is disabled on mobile for performance
- Carousel uses Embla for smooth, accessible sliding
- Form integration ready with React Hook Form (add form fields as needed)

## 📞 Support

For questions or customization requests, contact:
jestsmartservicesltd001@gmail.com

---

Built with ❤️ using Next.js, TypeScript, and Tailwind CSS
