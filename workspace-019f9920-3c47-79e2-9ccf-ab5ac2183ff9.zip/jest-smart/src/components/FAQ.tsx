"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Minus } from "lucide-react";
import ScrollReveal from "./ScrollReveal";

const faqs = [
  {
    q: "Do you install nationwide?",
    a: "Yes! We provide professional installation services across all 36 states in Nigeria. Our team of certified technicians is strategically located to ensure timely service delivery wherever you are.",
  },
  {
    q: "Do your products have warranty?",
    a: "Absolutely. All our products come with manufacturer warranties, and we also provide our own service warranty. Solar systems carry up to 5 years, security systems up to 3 years, and vehicles come with comprehensive inspection guarantees.",
  },
  {
    q: "How long does installation take?",
    a: "Installation timelines vary by project. A standard CCTV setup takes 1-2 days, solar systems typically 2-5 days, and inverter installations 1-2 days. We always provide a detailed timeline before starting any project.",
  },
  {
    q: "Can I request custom solutions?",
    a: "Of course! We specialize in custom solutions tailored to your specific needs. Whether it's a unique solar configuration, specialized security setup, or specific vehicle requirements, our team will design the perfect solution for you.",
  },
  {
    q: "Do you offer maintenance services?",
    a: "Yes, we offer comprehensive maintenance plans for all our installations. This includes regular inspections, preventive maintenance, system upgrades, and emergency response services to keep everything running optimally.",
  },
  {
    q: "What payment methods do you accept?",
    a: "We accept bank transfers, cash deposits, POS payments, and can arrange flexible payment plans for larger projects. We also work with select financing partners to make our solutions accessible to everyone.",
  },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="relative py-24 lg:py-32 overflow-hidden">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12 lg:mb-16">
          <ScrollReveal>
            <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#2563EB]/10 text-[#2563EB] text-sm font-semibold mb-4">
              FAQ
            </span>
          </ScrollReveal>
          <ScrollReveal delay={0.1}>
            <h2 className="font-[family-name:var(--font-space-grotesk)] text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1F3A] tracking-tight">
              Frequently Asked{" "}
              <span className="gradient-text">Questions</span>
            </h2>
          </ScrollReveal>
          <ScrollReveal delay={0.2}>
            <p className="mt-5 text-lg text-[#6B7280]">
              Everything you need to know about our services and solutions.
            </p>
          </ScrollReveal>
        </div>

        {/* FAQ Items */}
        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <ScrollReveal key={i} delay={i * 0.05}>
              <div
                className={`rounded-2xl border transition-all duration-300 overflow-hidden ${
                  open === i
                    ? "bg-white shadow-premium border-[#2563EB]/20"
                    : "bg-white/60 border-[#E5E7EB]/60 hover:border-[#2563EB]/20 hover:shadow-sm"
                }`}
              >
                <button
                  onClick={() => setOpen(open === i ? null : i)}
                  className="w-full flex items-center justify-between gap-4 p-6 text-left"
                  aria-expanded={open === i}
                >
                  <span className="font-semibold text-[#0B1F3A] text-sm sm:text-base">
                    {faq.q}
                  </span>
                  <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 ${
                    open === i
                      ? "bg-gradient-to-br from-[#2563EB] to-[#10B981] text-white rotate-180"
                      : "bg-[#F3F4F6] text-[#6B7280]"
                  }`}>
                    {open === i ? (
                      <Minus className="w-4 h-4" />
                    ) : (
                      <Plus className="w-4 h-4" />
                    )}
                  </div>
                </button>
                <AnimatePresence initial={false}>
                  {open === i && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
                      className="overflow-hidden"
                    >
                      <div className="px-6 pb-6">
                        <div className="h-px bg-gradient-to-r from-transparent via-[#E5E7EB] to-transparent mb-4" />
                        <p className="text-[#6B7280] leading-relaxed text-sm">
                          {faq.a}
                        </p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
}
