"use client";

import { MessageSquare, Lightbulb, Wrench, Smile } from "lucide-react";
import ScrollReveal from "./ScrollReveal";

const steps = [
  {
    number: "01",
    icon: MessageSquare,
    title: "Tell Us What You Need",
    description:
      "Reach out with your requirements — whether it's a vehicle, solar system, security setup, or merchandise.",
    color: "from-[#2563EB] to-[#1d4ed8]",
  },
  {
    number: "02",
    icon: Lightbulb,
    title: "Get Expert Recommendations",
    description:
      "Our specialists assess your needs and provide tailored solutions with transparent pricing.",
    color: "from-[#10B981] to-[#059669]",
  },
  {
    number: "03",
    icon: Wrench,
    title: "Professional Installation / Delivery",
    description:
      "Our certified technicians handle setup with precision, or we deliver your product safely to your door.",
    color: "from-[#F59E0B] to-[#D97706]",
  },
  {
    number: "04",
    icon: Smile,
    title: "Enjoy Peace of Mind",
    description:
      "Sit back and enjoy reliable performance backed by warranty, maintenance, and dedicated support.",
    color: "from-[#8B5CF6] to-[#7C3AED]",
  },
];

export default function Process() {
  return (
    <section className="relative py-24 lg:py-32 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-16 lg:mb-20">
          <ScrollReveal>
            <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#2563EB]/10 text-[#2563EB] text-sm font-semibold mb-4">
              How It Works
            </span>
          </ScrollReveal>
          <ScrollReveal delay={0.1}>
            <h2 className="font-[family-name:var(--font-space-grotesk)] text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1F3A] tracking-tight">
              Simple, Transparent,{" "}
              <span className="gradient-text">Seamless</span>
            </h2>
          </ScrollReveal>
          <ScrollReveal delay={0.2}>
            <p className="mt-5 text-lg text-[#6B7280] leading-relaxed">
              From first contact to final installation — our process is designed
              to be effortless at every step.
            </p>
          </ScrollReveal>
        </div>

        {/* Steps */}
        <div className="relative">
          {/* Connection line (desktop) */}
          <div className="hidden lg:block absolute top-24 left-[12.5%] right-[12.5%] h-0.5">
            <div className="h-full bg-gradient-to-r from-[#2563EB] via-[#10B981] to-[#8B5CF6] opacity-20 rounded-full" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#2563EB] via-[#10B981] to-[#8B5CF6] opacity-40 rounded-full" style={{
              backgroundSize: '200% 100%',
              animation: 'gradientShift 4s ease infinite'
            }} />
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-6 relative">
            {steps.map((step, i) => (
              <ScrollReveal key={i} delay={i * 0.1}>
                <div className="relative text-center group">
                  {/* Number badge */}
                  <div className="relative mx-auto mb-6 w-20 h-20">
                    <div className={`w-full h-full rounded-2xl bg-gradient-to-br ${step.color} flex items-center justify-center shadow-xl group-hover:scale-110 group-hover:rotate-6 transition-all duration-500`}>
                      <step.icon className="w-8 h-8 text-white" />
                    </div>
                    <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${step.color} opacity-0 group-hover:opacity-30 blur-xl transition-opacity duration-500`} />
                    <span className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-white shadow-lg flex items-center justify-center text-xs font-bold text-[#0B1F3A] border-2 border-[#F8FAFC]">
                      {step.number}
                    </span>
                  </div>

                  {/* Content */}
                  <h3 className="font-[family-name:var(--font-space-grotesk)] text-lg font-bold text-[#0B1F3A] mb-2">
                    {step.title}
                  </h3>
                  <p className="text-sm text-[#6B7280] leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
