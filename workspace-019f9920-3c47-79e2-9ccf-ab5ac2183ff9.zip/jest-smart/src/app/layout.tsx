import type { Metadata } from "next";
import { Inter, Space_Grotesk } from "next/font/google";
import "./globals.css";
import Script from "next/script";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const spaceGrotesk = Space_Grotesk({
  variable: "--font-space-grotesk",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://jestsmartservices.com"),
  title: {
    default: "Jest Smart Services Ltd | Premium Automobiles, Solar & Security Solutions",
    template: "%s | Jest Smart Services Ltd",
  },
  description:
    "Nigeria's trusted provider of premium automobiles, solar energy systems, CCTV security, inverter solutions, and general merchandise since 2008. Professional installation nationwide.",
  keywords: [
    "solar installation Nigeria",
    "CCTV cameras Abuja",
    "automobile sales Nigeria",
    "inverter systems",
    "security surveillance",
    "Jest Smart Services",
    "auto parts",
    "solar panels",
    "home security",
  ],
  authors: [{ name: "Jest Smart Services Ltd" }],
  creator: "Jest Smart Services Ltd",
  openGraph: {
    type: "website",
    locale: "en_NG",
    url: "https://jestsmartservices.com",
    title: "Jest Smart Services Ltd | Premium Solutions Since 2008",
    description:
      "Reliable automobiles, solar energy, security systems, and premium merchandise. Trusted by thousands of homeowners and businesses across Nigeria.",
    siteName: "Jest Smart Services Ltd",
    images: [
      {
        url: "/hero-image.jpg",
        width: 1200,
        height: 630,
        alt: "Jest Smart Services Ltd - Premium Solutions",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Jest Smart Services Ltd | Premium Solutions Since 2008",
    description:
      "Reliable automobiles, solar energy, security systems, and premium merchandise.",
    images: ["/hero-image.jpg"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
    },
  },
};

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  name: "Jest Smart Services Ltd",
  description:
    "Nigeria's trusted provider of premium automobiles, solar energy systems, CCTV security, inverter solutions, and general merchandise since 2008.",
  url: "https://jestsmartservices.com",
  email: "jestsmartservicesltd001@gmail.com",
  foundingDate: "2008",
  founder: {
    "@type": "Person",
    name: "John Funmilola Akinwunmi",
  },
  address: {
    "@type": "PostalAddress",
    addressLocality: "Abuja",
    addressRegion: "FCT",
    addressCountry: "NG",
  },
  areaServed: "Nigeria",
  serviceType: [
    "Automobile Sales",
    "Auto Parts",
    "Solar Energy Installation",
    "Inverter Systems",
    "CCTV & Security Installation",
    "General Merchandise",
  ],
  priceRange: "$$",
  image: "/hero-image.jpg",
  sameAs: [],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${inter.variable} ${spaceGrotesk.variable} h-full antialiased`}
      suppressHydrationWarning
    >
      <head>
        <Script
          id="json-ld"
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
          strategy="beforeInteractive"
        />
      </head>
      <body className="min-h-full flex flex-col bg-[#F8FAFC] text-[#111827]">
        {children}
      </body>
    </html>
  );
}
