"use client";

import { useEffect, useRef, useState } from "react";
import ScrollReveal from "./ScrollReveal";

interface StatProps {
  value: number;
  suffix: string;
  label: string;
  prefix?: string;
}

const stats: StatProps[] = [
  { value: 15, suffix: "+", label: "Years Experience", prefix: "" },
  { value: 5000, suffix: "+", label: "Satisfied Customers", prefix: "" },
  { value: 1000, suffix: "+", label: "Projects Completed", prefix: "" },
  { value: 99, suffix: "%", label: "Customer Satisfaction", prefix: "" },
];

function AnimatedCounter({ stat }: { stat: StatProps }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !inView) {
          setInView(true);
        }
      },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [inView]);

  useEffect(() => {
    if (!inView) return;
    const duration = 2000;
    const steps = 60;
    const increment = stat.value / steps;
    let current = 0;
    const timer = setInterval(() => {
      current += increment;
      if (current >= stat.value) {
        setCount(stat.value);
        clearInterval(timer);
      } else {
        setCount(Math.floor(current));
      }
    }, duration / steps);
    return () => clearInterval(timer);
  }, [inView, stat.value]);

  return (
    <div ref={ref} className="text-center group">
      <div className="inline-flex items-baseline">
        {stat.prefix && (
          <span className="font-[family-name:var(--font-space-grotesk)] text-4xl sm:text-5xl lg:text-6xl font-bold gradient-text">
            {stat.prefix}
          </span>
        )}
        <span className="font-[family-name:var(--font-space-grotesk)] text-4xl sm:text-5xl lg:text-6xl font-bold gradient-text">
          {count.toLocaleString()}
        </span>
        <span className="font-[family-name:var(--font-space-grotesk)] text-4xl sm:text-5xl lg:text-6xl font-bold gradient-text">
          {stat.suffix}
        </span>
      </div>
      <p className="mt-2 text-sm sm:text-base text-[#6B7280] font-medium">
        {stat.label}
      </p>
    </div>
  );
}

export default function Stats() {
  return (
    <section className="relative py-20 lg:py-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <ScrollReveal>
          <div className="relative rounded-3xl bg-white shadow-premium border border-white/50 overflow-hidden">
            {/* Decorative gradient */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#2563EB] via-[#10B981] to-[#2563EB]" />
            
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-4 p-8 sm:p-12 lg:p-16">
              {stats.map((stat, i) => (
                <ScrollReveal key={i} delay={i * 0.1}>
                  <div className={`${i > 0 ? "lg:border-l lg:border-[#E5E7EB]" : ""} lg:pl-4 ${i < stats.length - 1 ? "border-b lg:border-b-0 pb-8 lg:pb-0 border-[#E5E7EB] lg:border-r-0" : ""}`}>
                    <AnimatedCounter stat={stat} />
                  </div>
                </ScrollReveal>
              ))}
            </div>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
