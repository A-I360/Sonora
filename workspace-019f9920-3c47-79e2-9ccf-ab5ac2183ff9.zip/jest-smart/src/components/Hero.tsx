"use client";

import { motion } from "framer-motion";
import { ArrowRight, Shield, Sun, Car, Play } from "lucide-react";
import Link from "next/link";
import Image from "next/image";

const floatingCards = [
  {
    icon: Sun,
    label: "Solar Energy",
    desc: "24/7 Power",
    color: "from-[#10B981] to-[#059669]",
    position: "top-20 left-[5%]",
    delay: 0.5,
  },
  {
    icon: Shield,
    label: "CCTV Security",
    desc: "Full Protection",
    color: "from-[#2563EB] to-[#1d4ed8]",
    position: "top-[35%] right-[3%]",
    delay: 0.8,
  },
  {
    icon: Car,
    label: "Automobiles",
    desc: "Premium Quality",
    color: "from-[#0B1F3A] to-[#132d52]",
    position: "bottom-32 left-[8%]",
    delay: 1.1,
  },
];

export default function Hero() {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center overflow-hidden mesh-gradient-hero pt-20"
    >
      {/* Animated blobs */}
      <div className="absolute top-20 left-10 w-96 h-96 bg-[#2563EB]/20 rounded-full blur-[120px] animate-blob" />
      <div className="absolute bottom-20 right-10 w-80 h-80 bg-[#10B981]/15 rounded-full blur-[100px] animate-blob" style={{ animationDelay: "4s" }} />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#2563EB]/5 rounded-full blur-[150px]" />

      {/* Grid pattern overlay */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(rgba(255,255,255,0.05) 1px, transparent 1px)`,
          backgroundSize: '40px 40px'
        }} />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-12 lg:py-20">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Content */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm mb-6"
            >
              <span className="w-2 h-2 rounded-full bg-[#10B981] animate-pulse" />
              <span className="text-sm text-white/80 font-medium">
                Trusted Since 2008 — Over 5,000 Happy Customers
              </span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.1 }}
              className="font-[family-name:var(--font-space-grotesk)] text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold leading-[1.05] tracking-tight text-white"
            >
              Smart Solutions{" "}
              <br className="hidden sm:block" />
              for{" "}
              <span className="gradient-text-hero">
                Modern Living
              </span>
              .
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="mt-6 text-lg sm:text-xl text-white/60 max-w-lg leading-relaxed"
            >
              Reliable automobiles, solar energy systems, CCTV security,
              and premium merchandise — professionally installed and backed
              by over 15 years of excellence.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.3 }}
              className="mt-10 flex flex-wrap gap-4"
            >
              <Link
                href="#contact"
                className="group inline-flex items-center gap-2 px-8 py-4 rounded-full bg-gradient-to-r from-[#2563EB] to-[#10B981] text-white font-semibold shadow-xl shadow-[#2563EB]/20 hover:shadow-2xl hover:shadow-[#2563EB]/30 hover:scale-105 transition-all duration-300 cta-pulse"
              >
                Get Started
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link
                href="#services"
                className="group inline-flex items-center gap-2 px-8 py-4 rounded-full bg-white/5 border border-white/20 text-white font-semibold backdrop-blur-sm hover:bg-white/10 hover:border-white/30 transition-all duration-300"
              >
                <Play className="w-4 h-4" />
                Explore Services
              </Link>
            </motion.div>

            {/* Trust indicators */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.7, delay: 0.5 }}
              className="mt-12 flex flex-wrap items-center gap-6 text-white/40 text-sm"
            >
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-[#10B981]" />
                <span>Warranty Protected</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex -space-x-1">
                  {[...Array(5)].map((_, i) => (
                    <svg key={i} className="w-4 h-4 text-[#FBBF24]" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <span>4.9/5 Rating</span>
              </div>
            </motion.div>
          </div>

          {/* Right - Hero Image */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative hidden lg:block"
          >
            <div className="relative">
              {/* Main image */}
              <div className="relative rounded-3xl overflow-hidden shadow-2xl shadow-black/30 glow">
                <Image
                  src="/hero-image.jpg"
                  alt="Modern luxury home with solar panels, SUV, and security systems"
                  width={700}
                  height={500}
                  className="w-full h-auto object-cover"
                  priority
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#081018]/40 via-transparent to-transparent" />
              </div>

              {/* Floating cards */}
              {floatingCards.map((card, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: card.delay }}
                  className={`absolute ${card.position} animate-float`}
                  style={{ animationDelay: `${card.delay}s` }}
                >
                  <div className="glass-dark rounded-2xl p-4 shadow-xl flex items-center gap-3 min-w-[180px]">
                    <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${card.color} flex items-center justify-center shadow-lg`}>
                      <card.icon className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <p className="text-white font-semibold text-sm">{card.label}</p>
                      <p className="text-white/50 text-xs">{card.desc}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>

      {/* Bottom gradient fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#F8FAFC] to-transparent" />
    </section>
  );
}
