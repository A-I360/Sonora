"use client";

import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, Check } from "lucide-react";
import ScrollReveal from "./ScrollReveal";

const products = [
  {
    image: "/vehicle.jpg",
    title: "Premium Vehicles",
    description: "Brand new and foreign used automobiles",
    features: ["Brand New", "Foreign Used", "Nigerian Used", "Vehicle Sourcing"],
    accent: "#0B1F3A",
  },
  {
    image: "/solar.jpg",
    title: "Solar Panels & Systems",
    description: "Complete solar energy solutions",
    features: ["High-Efficiency Panels", "Solar Batteries", "Inverters", "Installation"],
    accent: "#10B981",
  },
  {
    image: "/cctv.jpg",
    title: "Security Cameras",
    description: "Advanced surveillance systems",
    features: ["IP Cameras", "DVR/NVR", "Video Doorbells", "Motion Sensors"],
    accent: "#2563EB",
  },
  {
    image: "/inverter.jpg",
    title: "Inverter & Batteries",
    description: "Reliable backup power systems",
    features: ["Home Inverters", "Office Systems", "Deep-Cycle Batteries", "Maintenance"],
    accent: "#F59E0B",
  },
];

export default function Products() {
  return (
    <section id="products" className="relative py-24 lg:py-32 overflow-hidden mesh-gradient-light">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#2563EB]/10 to-transparent" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-16 lg:mb-20">
          <ScrollReveal>
            <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#0B1F3A]/5 text-[#0B1F3A] text-sm font-semibold mb-4">
              Product Showcase
            </span>
          </ScrollReveal>
          <ScrollReveal delay={0.1}>
            <h2 className="font-[family-name:var(--font-space-grotesk)] text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1F3A] tracking-tight">
              Premium Products,{" "}
              <span className="gradient-text">Exceptional Quality</span>
            </h2>
          </ScrollReveal>
          <ScrollReveal delay={0.2}>
            <p className="mt-5 text-lg text-[#6B7280] leading-relaxed">
              Every product we offer is carefully sourced, rigorously tested,
              and backed by warranty for your complete peace of mind.
            </p>
          </ScrollReveal>
        </div>

        {/* Products Grid */}
        <div className="grid md:grid-cols-2 gap-6 lg:gap-8">
          {products.map((product, i) => (
            <ScrollReveal key={i} delay={i * 0.1}>
              <motion.div
                whileHover={{ y: -6 }}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
                className="group relative bg-white rounded-3xl overflow-hidden shadow-premium hover:shadow-premium-hover border border-white/80 transition-all duration-500"
              >
                {/* Image */}
                <div className="relative h-64 sm:h-72 overflow-hidden">
                  <Image
                    src={product.image}
                    alt={product.title}
                    fill
                    sizes="(max-width: 768px) 100vw, 50vw"
                    className="object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#081018]/80 via-[#081018]/20 to-transparent" />
                  <div className="absolute top-4 left-4">
                    <span
                      className="inline-block px-3 py-1 rounded-full text-xs font-semibold text-white backdrop-blur-md border border-white/20"
                      style={{ backgroundColor: `${product.accent}90` }}
                    >
                      Premium
                    </span>
                  </div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="font-[family-name:var(--font-space-grotesk)] text-2xl font-bold text-white">
                      {product.title}
                    </h3>
                    <p className="text-white/70 text-sm mt-1">{product.description}</p>
                  </div>
                </div>

                {/* Features */}
                <div className="p-6">
                  <ul className="grid grid-cols-2 gap-2 mb-6">
                    {product.features.map((feature, fi) => (
                      <li key={fi} className="flex items-center gap-2 text-sm text-[#374151]">
                        <Check className="w-4 h-4 text-[#10B981] flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Link
                    href="#contact"
                    className="inline-flex items-center gap-2 text-sm font-semibold text-[#2563EB] hover:text-[#0B1F3A] group/link transition-colors"
                  >
                    Request This Product
                    <ArrowRight className="w-4 h-4 group-hover/link:translate-x-1 transition-transform" />
                  </Link>
                </div>
              </motion.div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
}
