"use client";

import Link from "next/link";
import { ArrowRight, Mail, Phone } from "lucide-react";
import { motion } from "framer-motion";
import ScrollReveal from "./ScrollReveal";

export default function CTA() {
  return (
    <section id="contact" className="relative py-24 lg:py-32 overflow-hidden mesh-gradient-dark">
      {/* Decorative blobs */}
      <div className="absolute top-10 left-10 w-96 h-96 bg-[#2563EB]/15 rounded-full blur-[120px] animate-blob" />
      <div className="absolute bottom-10 right-10 w-80 h-80 bg-[#10B981]/10 rounded-full blur-[100px] animate-blob" style={{ animationDelay: "4s" }} />
      
      {/* Grid overlay */}
      <div className="absolute inset-0 opacity-10" style={{
        backgroundImage: `radial-gradient(rgba(255,255,255,0.08) 1px, transparent 1px)`,
        backgroundSize: '30px 30px'
      }} />

      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <ScrollReveal>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-white/80 text-sm font-semibold mb-6">
            <span className="w-2 h-2 rounded-full bg-[#10B981] animate-pulse" />
            Ready to Get Started?
          </div>
        </ScrollReveal>

        <ScrollReveal delay={0.1}>
          <h2 className="font-[family-name:var(--font-space-grotesk)] text-3xl sm:text-4xl lg:text-6xl font-bold text-white tracking-tight leading-tight">
            Let&apos;s Build a Smarter{" "}
            <span className="gradient-text-hero">Home Together</span>
          </h2>
        </ScrollReveal>

        <ScrollReveal delay={0.2}>
          <p className="mt-6 text-lg sm:text-xl text-white/60 max-w-2xl mx-auto leading-relaxed">
            Join thousands of satisfied customers who trust Jest Smart Services
            for their automobile, solar, security, and merchandise needs.
          </p>
        </ScrollReveal>

        <ScrollReveal delay={0.3}>
          <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center">
            <motion.a
              href="mailto:jestsmartservicesltd001@gmail.com"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
              className="group inline-flex items-center justify-center gap-2 px-8 py-4 rounded-full bg-gradient-to-r from-[#2563EB] to-[#10B981] text-white font-semibold shadow-xl shadow-[#2563EB]/20 hover:shadow-2xl hover:shadow-[#2563EB]/30 transition-all duration-300 cta-pulse"
            >
              Request a Free Quote
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </motion.a>
            <motion.a
              href="mailto:jestsmartservicesltd001@gmail.com"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
              className="group inline-flex items-center justify-center gap-2 px-8 py-4 rounded-full bg-white/5 border border-white/20 text-white font-semibold backdrop-blur-sm hover:bg-white/10 hover:border-white/30 transition-all duration-300"
            >
              <Mail className="w-4 h-4" />
              Email Us
            </motion.a>
          </div>
        </ScrollReveal>

        {/* Quick info */}
        <ScrollReveal delay={0.4}>
          <div className="mt-12 flex flex-col sm:flex-row gap-6 justify-center text-white/40 text-sm">
            <a href="mailto:jestsmartservicesltd001@gmail.com" className="flex items-center gap-2 hover:text-white/70 transition-colors">
              <Mail className="w-4 h-4" />
              jestsmartservicesltd001@gmail.com
            </a>
            <div className="hidden sm:block w-px h-5 bg-white/10 self-center" />
            <div className="flex items-center gap-2">
              <Phone className="w-4 h-4" />
              Response within 24 hours
            </div>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
