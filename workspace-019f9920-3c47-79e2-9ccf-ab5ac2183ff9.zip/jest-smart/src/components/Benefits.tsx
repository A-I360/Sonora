"use client";

import {
  Zap,
  Shield,
  BadgeDollarSign,
  Award,
  Wrench,
  TrendingUp,
  Headphones,
} from "lucide-react";
import ScrollReveal from "./ScrollReveal";

const benefits = [
  { icon: Zap, title: "Reliable Power", desc: "Uninterrupted energy with solar and inverter systems." },
  { icon: Shield, title: "Enhanced Security", desc: "24/7 surveillance and protection for your property." },
  { icon: BadgeDollarSign, title: "Affordable Prices", desc: "Premium quality at competitive, transparent rates." },
  { icon: Award, title: "Premium Quality", desc: "Only genuine, tested products from trusted brands." },
  { icon: Wrench, title: "Professional Installation", desc: "Certified technicians with meticulous attention to detail." },
  { icon: TrendingUp, title: "Long-term Value", desc: "Durable solutions that appreciate over time." },
  { icon: Headphones, title: "Excellent Support", desc: "Dedicated after-sales care whenever you need us." },
];

export default function Benefits() {
  return (
    <section className="relative py-24 lg:py-32 mesh-gradient-dark overflow-hidden">
      {/* Decorative */}
      <div className="absolute top-20 left-10 w-96 h-96 bg-[#2563EB]/10 rounded-full blur-[120px]" />
      <div className="absolute bottom-20 right-10 w-80 h-80 bg-[#10B981]/10 rounded-full blur-[100px]" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <ScrollReveal>
            <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-white/80 text-sm font-semibold mb-4">
              Benefits
            </span>
          </ScrollReveal>
          <ScrollReveal delay={0.1}>
            <h2 className="font-[family-name:var(--font-space-grotesk)] text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight">
              The Jest Smart{" "}
              <span className="gradient-text-hero">Advantage</span>
            </h2>
          </ScrollReveal>
          <ScrollReveal delay={0.2}>
            <p className="mt-5 text-lg text-white/60 leading-relaxed">
              Experience the difference that comes with choosing a partner
              committed to your long-term satisfaction.
            </p>
          </ScrollReveal>
        </div>

        {/* Benefits Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {benefits.map((benefit, i) => (
            <ScrollReveal key={i} delay={i * 0.05}>
              <div className="group relative glass-dark rounded-2xl p-6 hover:bg-white/10 transition-all duration-500 h-full">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#2563EB] to-[#10B981] flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                  <benefit.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-[family-name:var(--font-space-grotesk)] text-lg font-bold text-white mb-2">
                  {benefit.title}
                </h3>
                <p className="text-sm text-white/50 leading-relaxed">
                  {benefit.desc}
                </p>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
}
