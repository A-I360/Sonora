"use client";

import useEmblaCarousel from "embla-carousel-react";
import { useCallback, useEffect, useState } from "react";
import { ChevronLeft, ChevronRight, Star, Quote } from "lucide-react";
import ScrollReveal from "./ScrollReveal";

const testimonials = [
  {
    name: "Adaeze Okonkwo",
    role: "Homeowner, Abuja",
    avatar: "AO",
    color: "from-[#2563EB] to-[#10B981]",
    rating: 5,
    text: "Jest Smart installed a complete solar system in our home and the difference is incredible. We haven't had a single power issue in over a year. Their team was professional, punctual, and thorough.",
  },
  {
    name: "Ibrahim Musa",
    role: "Business Owner, Lagos",
    avatar: "IM",
    color: "from-[#10B981] to-[#059669]",
    rating: 5,
    text: "We needed a comprehensive CCTV setup for our warehouse. The installation was flawless and the quality of the cameras is outstanding. Best investment we made for our security.",
  },
  {
    name: "Chidinma Eze",
    role: "Real Estate Developer",
    avatar: "CE",
    color: "from-[#8B5CF6] to-[#7C3AED]",
    rating: 5,
    text: "I've purchased multiple vehicles through Jest Smart and every experience has been exceptional. Their inspection process is thorough and the prices are very fair. Highly recommended.",
  },
  {
    name: "Oluwaseun Adeyemi",
    role: "School Administrator",
    avatar: "OA",
    color: "from-[#F59E0B] to-[#D97706]",
    rating: 5,
    text: "The inverter system they installed for our school has been a game-changer. Reliable power during outages means our students never miss a lesson. Excellent service from start to finish.",
  },
  {
    name: "Fatima Abdullahi",
    role: "Corporate Executive",
    avatar: "FA",
    color: "from-[#EF4444] to-[#DC2626]",
    rating: 5,
    text: "From the initial consultation to final installation, everything was handled with utmost professionalism. The quality of products and customer service is unmatched in Nigeria.",
  },
];

export default function Testimonials() {
  const [emblaRef, emblaApi] = useEmblaCarousel({
    loop: true,
    align: "start",
    slidesToScroll: 1,
    breakpoints: {
      "(min-width: 768px)": { slidesToScroll: 2 },
      "(min-width: 1024px)": { slidesToScroll: 3 },
    },
  });

  const [canScrollPrev, setCanScrollPrev] = useState(false);
  const [canScrollNext, setCanScrollNext] = useState(true);

  const updateButtons = useCallback(() => {
    if (!emblaApi) return;
    setCanScrollPrev(emblaApi.canScrollPrev());
    setCanScrollNext(emblaApi.canScrollNext());
  }, [emblaApi]);

  useEffect(() => {
    if (!emblaApi) return;
    updateButtons();
    emblaApi.on("select", updateButtons);
    return () => { emblaApi.off("select", updateButtons); };
  }, [emblaApi, updateButtons]);

  const scrollPrev = useCallback(() => emblaApi?.scrollPrev(), [emblaApi]);
  const scrollNext = useCallback(() => emblaApi?.scrollNext(), [emblaApi]);

  return (
    <section id="testimonials" className="relative py-24 lg:py-32 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-12">
          <div className="max-w-2xl">
            <ScrollReveal>
              <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#10B981]/10 text-[#10B981] text-sm font-semibold mb-4">
                Testimonials
              </span>
            </ScrollReveal>
            <ScrollReveal delay={0.1}>
              <h2 className="font-[family-name:var(--font-space-grotesk)] text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1F3A] tracking-tight">
                Loved by{" "}
                <span className="gradient-text">Thousands</span>
              </h2>
            </ScrollReveal>
            <ScrollReveal delay={0.2}>
              <p className="mt-4 text-lg text-[#6B7280]">
                See what our customers across Nigeria have to say about their experience.
              </p>
            </ScrollReveal>
          </div>

          {/* Navigation */}
          <ScrollReveal direction="left">
            <div className="flex gap-3">
              <button
                onClick={scrollPrev}
                disabled={!canScrollPrev}
                className="w-12 h-12 rounded-full border border-[#E5E7EB] flex items-center justify-center text-[#0B1F3A] hover:bg-[#0B1F3A] hover:text-white hover:border-[#0B1F3A] transition-all duration-300 disabled:opacity-30 disabled:cursor-not-allowed"
                aria-label="Previous testimonials"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={scrollNext}
                disabled={!canScrollNext}
                className="w-12 h-12 rounded-full border border-[#E5E7EB] flex items-center justify-center text-[#0B1F3A] hover:bg-[#0B1F3A] hover:text-white hover:border-[#0B1F3A] transition-all duration-300 disabled:opacity-30 disabled:cursor-not-allowed"
                aria-label="Next testimonials"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </ScrollReveal>
        </div>

        {/* Carousel */}
        <div className="overflow-hidden" ref={emblaRef}>
          <div className="flex gap-6 -ml-2">
            {testimonials.map((t, i) => (
              <div
                key={i}
                className="flex-[0_0_100%] md:flex-[0_0_calc(50%-12px)] lg:flex-[0_0_calc(33.333%-16px)] pl-2"
              >
                <div className="h-full bg-white rounded-2xl p-8 shadow-premium border border-white/80 flex flex-col relative overflow-hidden group hover:shadow-premium-hover transition-shadow duration-500">
                  {/* Quote icon */}
                  <Quote className="absolute top-6 right-6 w-10 h-10 text-[#2563EB]/5 group-hover:text-[#2563EB]/10 transition-colors" />

                  {/* Stars */}
                  <div className="flex gap-0.5 mb-4">
                    {[...Array(t.rating)].map((_, si) => (
                      <Star key={si} className="w-4 h-4 fill-[#FBBF24] text-[#FBBF24]" />
                    ))}
                  </div>

                  {/* Text */}
                  <p className="text-[#374151] leading-relaxed flex-1 text-sm">
                    &ldquo;{t.text}&rdquo;
                  </p>

                  {/* Author */}
                  <div className="flex items-center gap-3 mt-6 pt-6 border-t border-[#E5E7EB]/60">
                    <div className={`w-11 h-11 rounded-full bg-gradient-to-br ${t.color} flex items-center justify-center text-white font-bold text-sm shadow-lg`}>
                      {t.avatar}
                    </div>
                    <div>
                      <p className="font-semibold text-[#0B1F3A] text-sm">{t.name}</p>
                      <p className="text-xs text-[#6B7280]">{t.role}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
